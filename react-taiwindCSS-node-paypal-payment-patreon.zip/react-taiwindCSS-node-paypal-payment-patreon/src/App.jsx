import FooterIcons from "./components/FooterIcons";
import HeroTextContent from "./components/HeroTextContent";
import ImageContainer from "./components/ImageContainer";
import NavIcons from "./components/NavIcons";
import NavLinks from "./components/NavLinks";
import RightFooter from "./components/RightFooter";
import { PayPalScriptProvider } from "@paypal/react-paypal-js";
import { Toaster } from "react-hot-toast";
import PageCount from "./components/PageCount";

function App() {
  const initialOptions = {
    "client-id": "Your Client Id Goes Here",
    currency: "USD",
    intent: "capture",
    // "data-client-token": "abc123xyz==",
  };

  return (
    <>
      <Toaster />
      <PayPalScriptProvider options={initialOptions}>
        <div className="w-screen h-screen  flex font-alata">
          <div className="flex flex-col justify-between h-full flex-1 pl-40 pr-24 pb-8">
            <NavLinks />
            <HeroTextContent />
            <FooterIcons />
          </div>
          <div className="flex flex-col justify-between h-full flex-1 bg-[#FFF0C8] pr-40 relative pb-8">
            <NavIcons />
            <ImageContainer />
            <PageCount />
            <RightFooter />
          </div>
        </div>
      </PayPalScriptProvider>
    </>
  );
}

export default App;

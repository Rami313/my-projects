import { usePayPalScriptReducer } from "@paypal/react-paypal-js";
import { useState } from "react";
import PaypPalPayment from "./PayPalPayment";

const HeroTextContent = () => {
  const [isClicked, setIsClicked] = useState(false);
  const [{ isPending }] = usePayPalScriptReducer();
  console.log(isPending);

  return (
    <div className="flex flex-col gap-8 items-start w-[80%]">
      <h1 className="text-7xl font-bold">Wood Candy Sofa</h1>
      <p className="text-[#999999]">
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Vel
        repudiandae eum, deleniti voluptatum quibusdam ea itaque possimus sint
        saepe quod a in debitis. Nam tenetur excepturi quidem sint debitis
        commodi?
      </p>
      <strong className="text-2xl font-semibold">$399.00</strong>
      <button
        className="bg-[#FFE8A9] px-8 py-2"
        onClick={() => setIsClicked(true)}
      >
        Buy now
      </button>
      {isClicked && (
        <div className="flex flex-col w-[400px] px-2 py-2 rounded-lg bg-[#ebebeb]">
          <h3 className="self-center text-2xl font-semibold text-sky-600 pb-2">
            Pay with PayPal{" "}
          </h3>
          {isPending ? <div>Loading...</div> : <PaypPalPayment />}
        </div>
      )}
    </div>
  );
};

export default HeroTextContent;

const NavLinks = () => {
  return (
    <div className="flex gap-32 justify-between text-[#999999]">
      <a href="#" className="py-4">
        Types
      </a>
      <a
        href="#"
        className="bg-[#FFE8A9] text-[#343434] font-semibold px-16 py-4"
      >
        Price
      </a>
      <a href="#" className="py-4">
        Connect
      </a>
    </div>
  );
};

export default NavLinks;
